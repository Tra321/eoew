create definer = root@localhost view user_account_stats as
select `u`.`id`                       AS `user_id`,
       `u`.`username`                 AS `username`,
       `u`.`role`                     AS `role`,
       count(`a`.`id`)                AS `total_accounts`,
       count(distinct `a`.`category`) AS `total_categories`
from (`account_manager`.`users` `u` left join `account_manager`.`accounts` `a` on ((`u`.`id` = `a`.`user_id`)))
group by `u`.`id`, `u`.`username`, `u`.`role`;

