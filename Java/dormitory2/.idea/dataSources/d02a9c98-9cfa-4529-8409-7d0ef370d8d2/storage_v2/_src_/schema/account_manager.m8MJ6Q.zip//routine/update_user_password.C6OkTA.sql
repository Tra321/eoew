create
    definer = root@localhost procedure update_user_password(IN p_user_id int, IN p_new_password varchar(255),
                                                            IN p_new_salt varchar(255))
BEGIN
    UPDATE users 
    SET password = p_new_password, 
        salt = p_new_salt,
        update_time = CURRENT_TIMESTAMP
    WHERE id = p_user_id;
END;

