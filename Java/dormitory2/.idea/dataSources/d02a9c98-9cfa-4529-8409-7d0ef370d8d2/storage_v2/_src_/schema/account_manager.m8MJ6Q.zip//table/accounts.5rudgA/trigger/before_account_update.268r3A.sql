create definer = root@localhost trigger before_account_update
    before update
    on accounts
    for each row
BEGIN
    SET NEW.update_time = CURRENT_TIMESTAMP;
END;

