create definer = root@localhost trigger before_user_update
    before update
    on users
    for each row
BEGIN
    SET NEW.update_time = CURRENT_TIMESTAMP;
END;

