create
    definer = root@localhost procedure add_user(IN p_username varchar(50), IN p_password varchar(255),
                                                IN p_salt varchar(255), IN p_role enum ('admin', 'user'))
BEGIN
    INSERT INTO users (username, password, salt, role)
    VALUES (p_username, p_password, p_salt, p_role);
END;

