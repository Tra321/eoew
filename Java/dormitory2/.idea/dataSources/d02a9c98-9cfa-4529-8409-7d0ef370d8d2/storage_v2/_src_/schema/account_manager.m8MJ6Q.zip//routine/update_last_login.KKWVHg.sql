create
    definer = root@localhost procedure update_last_login(IN p_user_id int)
BEGIN
    UPDATE users 
    SET last_login_time = CURRENT_TIMESTAMP
    WHERE id = p_user_id;
END;

